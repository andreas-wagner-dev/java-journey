package tutorial;

public class test {
	public static void main(String[] args) {
		GenericClass<String> stringContainer = new GenericClass<String>();
		stringContainer.setContent("hallo");
		String s = stringContainer.getContent();
		System.out.println(s);

		GenericClass<String> stringContainer1 = new GenericClass<String>();
		stringContainer1.setContent("hallo");
		String s1 = stringContainer1.getContent();
		System.out.println(s1);

		System.out.println(stringContainer1.equals(stringContainer));

		GenericClass<Integer> intContainer = new GenericClass<Integer>();
		intContainer.setContent(3);
		int i = intContainer.getContent();
		System.out.println(i);

		GenericStack1<String> stringStack = new GenericStack1<String>(10);
		stringStack.push("hallo");
		stringStack.push("Welt");

		String top = stringStack.pop();
		System.out.println(top);
		top = stringStack.pop();
		System.out.println(top);
		top = stringStack.pop();
		System.out.println(top);

		String[] strArray = new String[10];
		@SuppressWarnings("unused")
		Object[] objArray = strArray;
		// objArray[0] = new Integer(1); //ArrayStoreException
		// boolean b = strArray[0].endsWith("hallo");
		// System.out.println("b = " + b);

		// GenericStack<String> ls1 = new GenericStack<String>(10);
		// GenericStack<Object> lo1 = ls1; //Fehler

		// GenericStack<String> ls2 = new GenericStack<String>(10);
		// GenericStack<? extends Object> lo2 = ls2;
		// lo2.add(new Object());

		// GenericClass<String>[] str = new GenericClass<String>[10];

		GenericClass<String> hallo = new GenericClass<String>();
		hallo.setContent("hallo");
		GenericClass<String> welt = new GenericClass<String>();
		welt.setContent("welt");
		Exchange1<String> t11 = new Exchange1<String>();
		t11.exchange(hallo, welt);
		System.out.println(hallo.getContent() + ", " + welt.getContent());
		GenericClass<Integer> int1 = new GenericClass<Integer>();
		int1.setContent(47);
		GenericClass<Integer> int2 = new GenericClass<Integer>();
		int2.setContent(11);
		// t1.exchange(int1, int2); //Fehler
		Exchange1<Integer> t12 = new Exchange1<Integer>();
		t12.exchange(int1, int2);
		System.out.println("" + int1.getContent() + +int2.getContent());

		Exchange2.exchange(hallo, welt);
		System.out.println(hallo.getContent() + ", " + welt.getContent());
		Exchange2.exchange(int1, int2);
		System.out.println("" + int1.getContent() + +int2.getContent());
		// Exchange2.exchange(hallo, int1);
	}
}

class GenericClass<T> {
	private T content;

	public T getContent() {
		return content;
	}

	public void setContent(T content) {
		this.content = content;
	}

	@Override
	public boolean equals(Object obj) {

		// TODO Auto-generated method stub
		return this.content.equals(((GenericClass) obj).getContent());
	}

}

class GenericStack1<T> {
	private int top;
	private T[] stack;

	@SuppressWarnings("unchecked")
	public GenericStack1(int initialLength) {
		top = 0;
		stack = (T[]) new Object[initialLength];
	}

	@SuppressWarnings("unchecked")
	public void push(T o) {
		if (top == stack.length) {
			// Keller vergroessern auf das Doppelte
			T[] newStack = (T[]) new Object[2 * stack.length];
			for (int i = 0; i < stack.length; i++) {
				newStack[i] = stack[i];
			}
			stack = newStack;
		}
		stack[top++] = o;
	}

	public T pop() {
		if (top > 0) {
			T result = stack[top - 1];
			stack[top - 1] = null; // garbage collection
			top--;
			return result;
		} else {
			return null;
		}
	}
}

class GenericStack2<T> {
	private int top;
	private Object[] stack;

	public GenericStack2(int initialLength) {
		top = 0;
		stack = new Object[initialLength];
	}

	public void push(T o) {
		if (top == stack.length) {
			// Keller vergroessern auf das Doppelte
			Object[] newStack = new Object[2 * stack.length];
			for (int i = 0; i < stack.length; i++) {
				newStack[i] = stack[i];
			}
			stack = newStack;
		}
		stack[top++] = o;
	}

	@SuppressWarnings("unchecked")
	public T pop() {
		if (top > 0) {
			T result = (T) stack[top - 1];
			stack[top - 1] = null; // garbage collection
			top--;
			return result;
		} else {
			return null;
		}
	}
}

class Exchange1<T> {
	public void exchange(GenericClass<T> o1, GenericClass<T> o2) {
		T content1 = o1.getContent();
		T content2 = o2.getContent();
		o1.setContent(content2);
		o2.setContent(content1);
	}
}

class Exchange2 {
	public static <T> void exchange(GenericClass<T> o1, GenericClass<T> o2) {
		T content1 = o1.getContent();
		T content2 = o2.getContent();
		o1.setContent(content2);
		o2.setContent(content1);
	}
}
