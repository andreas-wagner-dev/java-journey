package tutorial;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

public class TcpSocketServer {

	public static void main(String[] args) throws Throwable {
		// open server socket on port
		int port = 1250;
		try (ServerSocket serverSocket = new ServerSocket(port)) {
			// do for ever
			while (true) {
				System.out.println("listening on port...." + port);
				// listening on port and try to receive a request from client (socket)
				Socket acceptedRequest = serverSocket.accept();

				// read the request stream (bytes) to string with UTF-8 encoding
				InputStream inputStream = acceptedRequest.getInputStream();
				// get the output channel
				OutputStream outputStream = acceptedRequest.getOutputStream();

				// read input stream as string UTF-8
				String message = readInputStreamAsString(inputStream, StandardCharsets.UTF_8.name());
				// print message
				System.out.println(message);

				// if message is 'hello', greeting back
				if ("hello".equalsIgnoreCase(message)) {
					byte[] messageAsBytes = message.getBytes(StandardCharsets.UTF_8);
					outputStream.write(messageAsBytes);
				} else if ("andreas".equalsIgnoreCase(message)) {
					// if message is 'ANDREAS', say no access
					byte[] messageAsBytes = "no access".getBytes(StandardCharsets.UTF_8);
					outputStream.write(messageAsBytes);
				} else {
					// say do not understand
					byte[] messageAsBytes = "not understand".getBytes(StandardCharsets.UTF_8);
					outputStream.write(messageAsBytes);
				}
				// send to client
				outputStream.flush();
				outputStream.close();

			}
		}

	}

	static String readStringFromStream(InputStream inputStream, String charSet)
			throws IOException, UnsupportedEncodingException {
		ByteArrayOutputStream result = new ByteArrayOutputStream();
		byte[] buffer = new byte[1024];
		for (int length; (length = inputStream.read(buffer)) != -1;) {
			result.write(buffer, 0, length);
		}
		// StandardCharsets.UTF_8.name() > JDK 7
		String message = result.toString(charSet);
		return message;
	}

	public static String readInputStreamAsString(InputStream in, String charSet) throws IOException {

		BufferedInputStream bis = new BufferedInputStream(in);
		ByteArrayOutputStream buf = new ByteArrayOutputStream();
		int result = bis.read();
		while (result != -1) {
			byte b = (byte) result;
			buf.write(b);
			result = bis.read();
		}
//		in.close();
		return buf.toString(charSet);
	}
}
