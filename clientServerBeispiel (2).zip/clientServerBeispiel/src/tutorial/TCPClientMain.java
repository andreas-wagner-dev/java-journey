package tutorial;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class TCPClientMain {
	public static void main(String[] args) {
		int sendedFirstMessage = 0;
		try {
			Socket socket = new Socket("localhost", 1250);
			System.out.println("Connected to server: " + socket);

			Scanner serverIn = new Scanner(socket.getInputStream());
			PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
			Scanner sc = new Scanner(System.in);

			Thread serverThread = new Thread(() -> {
				while (true) {

					if (serverIn.hasNextLine()) {
						String message = serverIn.nextLine();
						System.out.println("Service: " + message);
						System.out.print("You: ");
						if (message.equalsIgnoreCase("bye")) {
							break;
						}
					}
				}
			});
			serverThread.start();

			while (true) {
				if (sendedFirstMessage == 0) {
					System.out.print("You: ");
					sendedFirstMessage++;
				}
				String message = sc.nextLine();
				out.println(message);

				if (message.equalsIgnoreCase("bye")) {
					break;
				}
			}

			serverThread.join();
			serverIn.close();
			out.close();
			sc.close();
			socket.close();
		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		}
	}
}
