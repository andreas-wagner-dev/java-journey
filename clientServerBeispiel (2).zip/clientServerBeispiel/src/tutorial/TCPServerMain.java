package tutorial;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class TCPServerMain {
	public static void main(String[] args) {
		try {
			ServerSocket serverSocket = new ServerSocket(1250);
			System.out.println("Server started and listening on port 1250...");

			Socket clientSocket = serverSocket.accept();
			System.out.println("Client connected: " + clientSocket);

			Scanner clientIn = new Scanner(clientSocket.getInputStream());
			PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
			Scanner sc = new Scanner(System.in);

			Thread clientThread = new Thread(() -> {
				while (true) {
					if (clientIn.hasNextLine()) {
						String message = clientIn.nextLine();
						System.out.println("Customer: " + message);
						System.out.print("You: ");
						if (message.equalsIgnoreCase("bye")) {
							break;
						}
					}
				}
			});
			clientThread.start();
			while (true) {
				String message = sc.nextLine();
				out.println(message);

				if (message.equalsIgnoreCase("bye")) {
					break;
				}
			}
			clientThread.join();
			clientIn.close();
			out.close();
			sc.close();
			clientSocket.close();
			serverSocket.close();
		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		}
	}
}